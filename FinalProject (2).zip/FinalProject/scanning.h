/*
 * scanning.h
 *
 *  Created on: Apr 24, 2023
 *      Author: elsabado
 */

#ifndef SCANNING_H_
#define SCANNING_H_

void scanAll(/*double objects[16][5]*/void);

void freeScan(void);

void freeScan1(void);

void scanShortAll(void);


#endif /* SCANNING_H_ */
