#define RICK_ROLL			0
#define IMERPIAL_MARCH 		1
#define MARIO_UNDERWORLD	3
#define MARIO_UNDERWATER	7



/// Loads some songs over the open interface
void load_songs();
